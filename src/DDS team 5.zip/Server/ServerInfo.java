
//simple structure to hold server info from server_config
public class ServerInfo {

    public String name, ip;
    public int port;

    public ServerInfo(String n, String i, int p){
        this.name = n;
        this.ip = i;
        this.port = p;
    }


}
